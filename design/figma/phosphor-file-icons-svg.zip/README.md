# Phosphor 文件图标预览

从 Phosphor Icons 官方仓库提取的 24 枚 Duotone SVG，保留原始路径、透明度和 currentColor。
来源版本：2b75f3ad12b420c9504ef05df8d2564a28f8500e。许可证见 LICENSE。扩展名映射和上游路径见 manifest.json。

本目录用于 Figma 选型预览，尚未接入 Windows 或 Android 客户端。分类配色为预览建议，不属于原始图标配色。
安装包使用原库 package 图标作为类别替代；JSON、XML、YAML 共用 file-code；无专用图形的格式使用对应类别或通用文件图标。
